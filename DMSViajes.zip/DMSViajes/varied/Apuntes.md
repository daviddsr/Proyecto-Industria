geolocalizacion.
opiniones de otros viajeros (via web, facebook, twitter).
Subpágina: ciudad de origen con ofertas.
Busca con google en nuestra página.
Pinchas en el país y te salen cuatro ciudades importantes y un input con autocompletar para elegir otra ciudad.